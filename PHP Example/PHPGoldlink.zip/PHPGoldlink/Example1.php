<!DOCTYPE html>
<html>
	<head>
		<title>GoldLink with PHP - Basic Examples</title>
	</head>
	<body>
		<h3>GoldLink with PHP - Basic Examples</h3>
		<?php
			// Include the required classes
			include 'GVGoldLinkNTLM.php';

			// The URL of the WSDL file for Gold-Link
			$url = 'http://' . $GVAddress . '/gold-link/goldlink.asmx?wsdl';

			// Unregister the current HTTP wrapper
			stream_wrapper_unregister('http');

			// Register the new HTTP wrapper
			stream_wrapper_register('http', 'GVGoldLinkNTLMStream') or die("Failed to register protocol");

			// Now, all requests to a http page will be done by GVGoldLinkNTLMStream.
			// Instantiate the client
			$GVGLclient = new GVGoldLinkNTLMSoapClient($url);

			//Gold-Vision Version
			$GVVersion = $GVGLclient->GetVersion()->{'GetVersionResult'};
			echo '<p>GV Version: '.$GVVersion.'</p>';

			//Is Gold-Vision Licenced
			$GVLicenced = $GVGLclient->IsLicenced()->{'IsLicencedResult'};
			echo '<p>GV Licenced: '.$GVLicenced.'</p>';

			// Restore the original HTTP stream wrapper
			stream_wrapper_restore('http');
		?>
	</body>
</html>