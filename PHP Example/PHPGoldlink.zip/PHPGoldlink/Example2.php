<!DOCTYPE html>
<html>
	<head>
		<title>GoldLink with PHP - Find an Account</title>
	</head>
	<body>
		<h3>GoldLink with PHP - Find an Account</h3>
		<?php
			// Include the required classes
			include 'GVGoldLinkNTLM.php';

			//Get the passed search term
			if (isset($_GET["searchterm"]))
				$searchterm = $_GET["searchterm"];
			else
				$searchterm = '';
				
			//Output the passed search term
			echo 'Search Term: ' . $searchterm;
			
			// The URL of the WSDL file for Gold-Link
			$url = 'http://' . $GVAddress . '/gold-link/goldlink.asmx?wsdl';

			// Unregister the current HTTP wrapper
			stream_wrapper_unregister('http');

			// Register the new HTTP wrapper
			stream_wrapper_register('http', 'GVGoldLinkNTLMStream') or die("Failed to register protocol");

			// Now, all requests to a http page will be done by GVGoldLinkNTLMStream.
			// Instantiate the client
			$GVGLclient = new GVGoldLinkNTLMSoapClient($url,array('trace' => TRUE));

			// Find a Gold-Vision Account(s)
			// Set the objectType to Account
			$FindItem->objectType = 'Account';

			// Set FindItem XmlFilters
			$FindItem->XmlFilters = new SoapVar('<ns1:XmlFilters><filters xmlns=""><filter dbcolumn="SUMMARY" type="text" value="'.$searchterm.'" /></filters></ns1:XmlFilters>',XSD_ANYXML);

			// Get the found accounts (if any)
			$result = $GVGLclient->FindItem($FindItem);
			if ($result->{'success'})
			{
				$GVAccountXML = new SimpleXMLElement($result->{'FindItemResult'}->{'any'});
				$ReturnedAccounts = $GVAccountXML->children();

				// Set the name of the atribute to display
				$att = 'summary';
			
				//Loop and output
				foreach ($ReturnedAccounts->children() as $child)
				{
					echo '<p>Account retrieved: ' . $child->attributes()->$att . "</p>";
				}
			}
			else
			{
				echo 'Failed: '.$result->{'message'};
				echo '<br />' . $GVGLclient->__getLastRequest();
			}

			// Restore the original HTTP stream wrapper
			stream_wrapper_restore('http');
		?>
	</body>
</html>